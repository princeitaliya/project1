function i2(){
    document.getElementById("si2").style.display="block";

    document.getElementById("si1").style.display="none";

    document.getElementById("si3").style.display="none";

    document.getElementById("si4").style.display="none";

    document.getElementById("si5").style.display="none";
    
}
function i1(){
    document.getElementById("si1").style.display="block";

    document.getElementById("si2").style.display="none";

    document.getElementById("si3").style.display="none";

    document.getElementById("si4").style.display="none";

    document.getElementById("si5").style.display="none";
    
}
function i3(){
    document.getElementById("si3").style.display="block";

    document.getElementById("si1").style.display="none";

    document.getElementById("si2").style.display="none";

    document.getElementById("si4").style.display="none";

    document.getElementById("si5").style.display="none";
    
}
function i4(){
    document.getElementById("si4").style.display="block";

    document.getElementById("si1").style.display="none";

    document.getElementById("si2").style.display="none";

    document.getElementById("si3").style.display="none";

    document.getElementById("si5").style.display="none";
    
}
function i5(){
    document.getElementById("si5").style.display="block";

    document.getElementById("si1").style.display="none";

    document.getElementById("si2").style.display="none";

    document.getElementById("si3").style.display="none";

    document.getElementById("si4").style.display="none";
    
}